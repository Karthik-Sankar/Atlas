#include<stdio.h>
extern int k;
int main()
{
 register int i=10;
 printf("%d\n",i);
}
